const COMMUNITY_DEMO_SEED={
  "strains": [
    {
      "id": 101,
      "name": "Demo Citrus"
    },
    {
      "id": 102,
      "name": "Demo Cedar"
    },
    {
      "id": 103,
      "name": "Demo Unrated"
    }
  ],
  "dispensaries": [
    {
      "id": 201,
      "name": "Demo Community Shop",
      "location": "Fixture City"
    },
    {
      "id": 202,
      "name": "Demo New Shop",
      "location": "Fixture Town"
    }
  ],
  "strain_reviews": [
    {
      "id": "10000000-0000-4000-8000-000000000001",
      "strain_id": 101,
      "user_id": "11111111-1111-4111-8111-111111111111",
      "brand": "Demo Grower",
      "product_type": "Flower",
      "aesthetic": 20,
      "aroma": 20,
      "flavor": 20,
      "effects": 20,
      "overall": 20,
      "total": 100,
      "notes": "Synthetic preview review. No real user information.",
      "photo_path": null,
      "created_at": "2026-01-01T12:00:00Z",
      "updated_at": "2026-01-01T12:00:00Z"
    },
    {
      "id": "10000000-0000-4000-8000-000000000002",
      "strain_id": 101,
      "user_id": "11111111-1111-4111-8111-111111111111",
      "brand": "Demo Grower",
      "product_type": "Pre-Roll",
      "aesthetic": 40,
      "aroma": 40,
      "flavor": 40,
      "effects": 40,
      "overall": 40,
      "total": 200,
      "notes": "A second format from the same person: still only one community contribution.",
      "photo_path": null,
      "created_at": "2026-01-02T12:00:00Z",
      "updated_at": "2026-01-02T12:00:00Z"
    },
    {
      "id": "10000000-0000-4000-8000-000000000003",
      "strain_id": 101,
      "user_id": "22222222-2222-4222-8222-222222222222",
      "brand": "Demo Grower",
      "product_type": "Flower",
      "aesthetic": 81,
      "aroma": 81,
      "flavor": 81,
      "effects": 81,
      "overall": 81,
      "total": 405,
      "notes": "A different person has equal weight in the community score.",
      "photo_path": null,
      "created_at": "2026-01-03T12:00:00Z",
      "updated_at": "2026-01-03T12:00:00Z"
    },
    {
      "id": "10000000-0000-4000-8000-000000000004",
      "strain_id": 102,
      "user_id": "11111111-1111-4111-8111-111111111111",
      "brand": "Demo Producer",
      "product_type": "Flower",
      "aesthetic": 60,
      "aroma": 60,
      "flavor": 60,
      "effects": 60,
      "overall": 60,
      "total": 300,
      "notes": "One reviewer example.",
      "photo_path": null,
      "created_at": "2026-01-01T12:00:00Z",
      "updated_at": "2026-01-01T12:00:00Z"
    }
  ],
  "dispensary_reviews": [
    {
      "id": "20000000-0000-4000-8000-000000000001",
      "dispensary_id": 201,
      "user_id": "11111111-1111-4111-8111-111111111111",
      "name": "Demo Community Shop",
      "location": "Fixture City",
      "aesthetic": 60,
      "accessibility": 60,
      "staff": 60,
      "menu": 60,
      "overall": 60,
      "total": 300,
      "notes": "Synthetic preview only.",
      "photo_path": null,
      "created_at": "2026-01-01T12:00:00Z"
    },
    {
      "id": "20000000-0000-4000-8000-000000000002",
      "dispensary_id": 201,
      "user_id": "22222222-2222-4222-8222-222222222222",
      "name": "Demo Community Shop",
      "location": "Fixture City",
      "aesthetic": 61,
      "accessibility": 62,
      "staff": 63,
      "menu": 64,
      "overall": 65,
      "total": 315,
      "notes": "Second synthetic account.",
      "photo_path": null,
      "created_at": "2026-01-02T12:00:00Z"
    }
  ]
}
;
/* Stable preview identifiers. Numeric IDs connect to existing review tables. */
window.Rated420CatalogueFixtures=(()=>{
  const licensed=[
    ['treehouse','Treehouse Cannabis','OCM-CAURD-24-000122','247F0832-EE2F-415D-BA98-1FEDA9F69062',2101,'https://www.treehousecannabis.com/','https://www.youtube.com/watch?v=5A0oNueR_SM'],
    ['kings-house','Kings House of Fire','OCM-CAURD-24-000104','B4D783E6-C71E-4B60-9552-8CA67039826B',2102,'https://www.kingshouseoffire.com/',''],
    ['peek-buds','Peek Buds','OCM-CAURD-26-000342','A78B0002-E662-44C8-9CC4-8E85CE34660F',2103,'https://peekbuds.com/',''],
    ['flowery-haverstraw','The Flowery · Haverstraw','OCM-RETL-24-000157','12B5CE96-5BC6-4155-B804-09A3BC5CF55A',2104,'https://www.thefloweryny.com/',''],
    ['kushmart-haverstraw','Kushmart · Haverstraw','OCM-RETL-24-000060','C27D332E-F3F9-49C8-B52B-C416133FF54B',2105,'','']
  ].map(([id,name,license,location,reviewId,url,media])=>({id,type:'dispensary',name,reviewId,url,media,
    licenseId:'ocm-'+license+'~'+location,description:'New York dispensary profile with a location-specific OCM record.',source:'OCM license snapshot · jskf-tt3q',origin:'Official regulatory record with editorial profile',state:'Published'}));
  const brands=[
    ['rythm','RYTHM','https://rythm.com/'],
    ['find','Find.','https://findcannabis.com/'],
    ['botanist','The Botanist','https://shopbotanist.com/'],
    ['nanticoke','Nanticoke','https://nanticoke.co/']
  ].map(([id,name,url])=>({id,type:'brand',name,url,reviewId:'catalogue-'+id,
    description:'Browse the official brand site for its current product information.',source:'Official brand website · checked 2026-11-20',origin:'Rated420 editorial profile',state:'Published'}));
  const synthetic=[
    {id:'strain-citrus',type:'strain',name:'Demo Citrus',reviewId:101,description:'A fictional cultivar connected to the existing demo scorecard.'},
    {id:'strain-amber',type:'strain',name:'Amber Trail Flower',reviewId:104,description:'A fictional cultivar in the Rated420 demo catalogue.'},
    {id:'org-farm',type:'cultivator',name:'Hudson Lantern Farm',description:'Fictional New York producer. Appears in the existing founder workspace.'},
    {id:'org-brand',type:'brand',name:'Field Signal',reviewId:'org-brand',description:'Fictional brand and business account organization.'},
    {id:'org-shop',type:'dispensary',name:'North Loop Dispensary',reviewId:201,description:'Fictional dispensary with simulated community ratings.'},
    {id:'product-amber',type:'product',name:'Amber Trail Flower · Demo',description:'A synthetic example of a finished product distinct from its cultivar.',
      brand:'org-brand',strain:'strain-amber',producer:'org-farm',dispensaries:['org-shop'],format:'Flower'},
    {id:'product-citrus-roll',type:'product',name:'Demo Citrus Pre-Roll',description:'A synthetic example linking a cultivar, brand and retailer.',
      brand:'org-brand',strain:'strain-citrus',producer:'org-farm',dispensaries:['org-shop'],format:'Pre-Roll'},
    {id:'product-citrus-vape',type:'product',name:'Demo Citrus Cartridge',description:'A second fictional format for the same cultivar.',
      brand:'org-brand',strain:'strain-citrus',producer:'org-farm',dispensaries:[],format:'Vape Cartridge'}
  ].map(row=>({...row,source:'Rated420 synthetic fixtures',origin:'Synthetic demonstration',state:'Published'}));
  return {licensed,brands,records:[...licensed,...brands,...synthetic]};
})();

/* Shared identity and catalog references for the complete offline build. */
const COMPLETE_ACCOUNTS = [
  {id:'11111111-1111-4111-8111-111111111111',label:'Community member · Maya',username:'demo_a',name:'Maya Vale',email:'maya@example.test'},
  {id:'22222222-2222-4222-8222-222222222222',label:'Alternate member · Riley',username:'demo_b',name:'Riley West',email:'riley@example.test'},
  {id:'aaaa0000-0000-4000-8000-000000000002',label:'Administrator · Adair',username:'demo_admin',name:'Adair Hart',email:'adair@example.test',role:'administrator'},
  {id:'aaaa0000-0000-4000-8000-000000000003',label:'Moderator · Camille',username:'demo_staff',name:'Camille Brooks',email:'camille@example.test',role:'staff'},
  {id:'aaaa0000-0000-4000-8000-000000000004',label:'Business representative · Morgan',username:'demo_business',name:'Morgan Lane',email:'morgan@example.test',organization:'org-brand'},
  {id:'aaaa0000-0000-4000-8000-000000000005',label:'Founder · Jordan',username:'demo_founder',name:'Jordan Ellis',email:'jordan@example.test',role:'staff',founder:true}
];
const COMPLETE_ENTITIES = [
  {id:'org-farm',name:'Hudson Lantern Farm',kind:'Producer',products:[101,104]},
  {id:'org-brand',name:'Field Signal',kind:'Brand',products:[101,104]},
  {id:'org-shop',name:'North Loop Dispensary',kind:'Dispensary',products:[101,104],listing:201}
];
const COMPLETE_REVIEW_FORMATS=['Flower','Pre-Roll','Infused Pre-Roll','Vape Cartridge','Disposable Vape','Concentrate','Edible','Tincture','Topical','Other'];
COMMUNITY_DEMO_SEED.strains.push({id:104,name:'Amber Trail Flower'});

Object.assign(COMMUNITY_DEMO_SEED.dispensaries[0],{name:'North Loop Dispensary',location:'Albany, NY'});

for(const row of window.Rated420CatalogueFixtures?.licensed||[]){
  const prefix=row.licenseId.slice(4).split('~');
  // Keep review IDs distinct from source/licensing identifiers.
  const locations={'OCM-CAURD-24-000122':'Nyack, NY','OCM-CAURD-24-000104':'Cortlandt Manor, NY',
    'OCM-CAURD-26-000342':'Peekskill, NY','OCM-RETL-24-000157':'Haverstraw, NY','OCM-RETL-24-000060':'Haverstraw, NY'};
  COMMUNITY_DEMO_SEED.dispensaries.push({id:row.reviewId,name:row.name,location:locations[prefix[0]]});
}

/* Synthetic Build 01 data adapter. The real authorization checks live in PostgreSQL. */
function runBuild01Fixture(operation, payload, state, actor, users, profile) {
  const complete=typeof COMPLETE_ENTITIES!=='undefined';
  const personalAccessory=item=>item.kind==='accessory'&&['houseplant-grinder','puffco'].includes(item.id);
  const fixtures = state.build01 ??= {
    items: [
      { id: 'demo-brand', kind: 'brand', name: 'Demo Orchard Co.', description: 'Synthetic brand for local review testing.' },
      { id: 'houseplant-grinder', kind: 'accessory', name: 'Shen’s blue Houseplant glass grinder', description: 'Accessory fixture supplied in the Build 01 brief.' },
      { id: 'puffco', kind: 'accessory', name: 'Al’s Puffco', description: 'Accessory fixture supplied in the Build 01 brief.' }
    ].filter(item=>!complete||!personalAccessory(item)),
    reviews: [], favorites: [],
    polls: [{ id: 'demo-poll', question: 'What should The Vault cover next?', closed: false, options: ['New York growers', 'Dispensary design'], votes: {} }]
  };
  if(complete&&!fixtures.items.some(item=>item.id==='org-brand')){
    fixtures.items.push({id:'org-brand',kind:'brand',name:'Field Signal',description:'Synthetic brand affiliated with Hudson Lantern Farm.'});
  }
  if(complete)for(const row of window.Rated420CatalogueFixtures?.brands||[]){
    if(!fixtures.items.some(item=>item.id===row.reviewId)){
      fixtures.items.push({id:row.reviewId,kind:'brand',name:row.name,description:'Independent Rated420 brand scorecard.'});
    }
  }
  const { id, kind } = payload;
  const role=state.build02?.roles[actor];
  const staff = role ? role !== 'member' : complete ? Boolean(COMPLETE_ACCOUNTS.find(entry=>entry.id===actor)?.role) : [users[0],users[2],users[3]].includes(actor);
  const ownFavorites = () => fixtures.favorites.filter(row => row.actor === actor);
  const identity = (id, total) => {
    const { username, avatar_choice, show_review_identity } = profile(state, id);
    return { total, username: show_review_identity ? username : null, avatar_choice: show_review_identity ? avatar_choice : null };
  };
  const catalog = fixtures.items.filter(item=>!complete||!personalAccessory(item)).map(item => {
    const reviews = fixtures.reviews.filter(row => row.id === item.id);
    return {
      ...item, count: reviews.length,
      average: reviews.length ? reviews.reduce((sum, row) => sum + row.total, 0) / reviews.length : null
    };
  });
  if (operation === 'catalog') return catalog.filter(item => item.kind === kind && (!complete || payload.manage || !state.build02?.archive?.includes(item.kind+':'+item.id)));
  if (operation === 'item') {
    const item = catalog.find(row => row.id === id && row.kind === kind);
    if (!item || (complete && state.build02?.archive?.includes(kind+':'+id))) return null;
    const reviews = fixtures.reviews.filter(row => row.id === id);
    return {
      ...item, own: reviews.find(row => row.actor === actor) ?? null,
      favorite: ownFavorites().some(row => row.kind === kind && row.id === id),
      reviews: reviews.map(row => identity(row.actor, row.total))
    };
  }
  if (operation === 'dispensary_reviews') {
    return state.dispensary_reviews.filter(row => String(row.dispensary_id) === id).map(row => identity(row.user_id, row.total));
  }
  if (operation === 'polls') return { staff, polls: fixtures.polls.map(poll => ({
    id: poll.id, question: poll.question, closed: poll.closed, vote: poll.votes[actor] ?? null,
    options: poll.options.map((label, i) => ({
      label, index: i + 1, votes: Object.values(poll.votes).filter(choice => choice === i + 1).length
    }))
  })) };
  if (!actor) throw new Error('Log in to continue.');
  if (operation === 'favorites') return ownFavorites().map(({ kind, id, name }) => ({ kind, id, name }));
  if (operation === 'favorite') {
    const listing = (kind === 'strain' ? state.strains : kind === 'dispensary' ? state.dispensaries : fixtures.items.filter(row => row.kind === 'brand'))
      .find(row => String(row.id) === id);
    if (!listing || !['strain', 'dispensary', 'brand'].includes(kind)) throw new Error('Listing not found.');
    fixtures.favorites = fixtures.favorites.filter(row => row.actor !== actor || row.kind !== kind || row.id !== id);
    if (payload.active) fixtures.favorites.push({ actor, kind, id, name: listing.name });
  } else if (operation === 'review') {
    const { scores, notes } = payload;
    if (!catalog.some(item => item.id === id && (!kind || item.kind === kind)) || !Array.isArray(scores) || scores.length !== 5 ||
        scores.some(value => !Number.isInteger(value) || value < 0 || value > 84) || notes.length > 1200) {
      throw new Error('Check your five scores and notes.');
    }
    const previous=fixtures.reviews.find(row=>row.actor===actor&&row.id===id);
    fixtures.reviews = fixtures.reviews.filter(row => row.actor !== actor || row.id !== id);
    fixtures.reviews.push({ id, actor, scores, notes: notes.trim(), activity_at:previous?.activity_at??new Date().toISOString(), total: scores.reduce((a, b) => a + b, 0) });
  } else if (operation === 'vote') {
    const poll = fixtures.polls.find(poll => poll.id === id);
    if (!poll || poll.closed) throw new Error('Voting is closed.');
    if (poll.votes[actor]) throw new Error('You have already voted.');
    if (![1, 2].includes(payload.option)) throw new Error('Choose a poll option.');
    poll.votes[actor] = payload.option;
    (poll.voteDates??={})[actor]=new Date().toISOString();
  } else if (operation === 'publish' && staff) {
    const question = payload.question.trim();
    const options = payload.options.map(value => value.trim());
    if (!question || question.length > 160 || options.length !== 2 || options.some(value => !value || value.length > 80)
        || options[0].toLowerCase() === options[1].toLowerCase()) throw new Error('Enter a question and two different options.');
    fixtures.polls.unshift({ id: crypto.randomUUID(), question, options, closed: false, votes: {} });
  } else if (operation === 'close' && staff) {
    const poll = fixtures.polls.find(poll => poll.id === id);
    if (poll) poll.closed = true;
  } else throw new Error('Action unavailable.');
  return null;
}

/* Browser-only fixtures. The production authorization boundary is the SQL RPC. */
function runBuild02Fixture(operation,payload,state,actor,users,profile,aggregate,defaultRoles) {
  const now=new Date().toISOString();
  if(!state.build01)runBuild01Fixture('polls',{},state,actor,users,profile);
  const b=state.build01;
  const h=state.build02??={
    roles:defaultRoles||{[users[0]]:'staff',[users[2]]:'administrator',[users[3]]:'staff'},
    submissions:[],archive:[],library:[
      {kind:'episode',id:'episode-one',title:'Rated 420:NY Episode 1 - AETERNA',description:'Verified public destination. Release date to be confirmed.',image:'artwork',url:'https://www.youtube.com/watch?v=_sIMx7bO0MQ',position:1,published:true},
      {kind:'episode',id:'episode-two',title:'Rated 420:NY Episode 2 - TREEHOUSE',description:'Verified public destination. Release date to be confirmed.',image:'artwork',url:'https://www.youtube.com/watch?v=5A0oNueR_SM',position:2,published:true},
      ...[['tee','Rated420 T-shirt'],['hoodie','Rated420 hoodie'],['hat','Rated420 cap'],['sticker','Rated420 sticker']].map(([image,title],i)=>({kind:'merch',id:image,title,image,description:'Rated420 artwork concept · Coming soon.',position:i,published:true}))
    ]
  };
  const role=h.roles[actor]||'member';
  const staff=role!=='member';
  const {kind,id}=payload;
  const hidden=r=>h.archive.includes(r.kind+':'+r.id);
  const score=(r,stats)=>({...r,average:stats?.avg_total??null,count:stats?.review_count??0});
  const strain=aggregate(state.strain_reviews,'strain_id',['aesthetic','aroma','flavor','effects','overall']);
  const disp=aggregate(state.dispensary_reviews,'dispensary_id',['aesthetic','accessibility','staff','menu','overall']);
  const rows=[
    ...state.strains.map(r=>score({...r,kind:'strain',formats:[...new Set(state.strain_reviews.filter(v=>Number(v.strain_id)===Number(r.id)).map(v=>v.product_type))]},strain.find(v=>Number(v.strain_id)===Number(r.id)))),
    ...state.dispensaries.map(r=>score({...r,kind:'dispensary'},disp.find(v=>Number(v.dispensary_id)===Number(r.id)))),
    ...['brand','accessory'].flatMap(kind=>runBuild01Fixture('catalog',{kind,manage:true},state,actor,users,profile))
  ];
  const same=(row,kind,name,location)=>row.kind===kind&&key(row.name)===key(name)&&key(row.location)===key(location);
  function key(v){return String(v??'').trim().toLowerCase().replace(/\s+/g,' ');}
  function validate(k,n,l,d){
    if(!['strain','dispensary','brand','accessory'].includes(k)||n.length<2||n.length>(k==='strain'?100:120)||d.length>1500||
      (k==='dispensary'?(l.length<2||l.length>120):Boolean(l)))throw Error('Enter a valid listing name, location and supporting details.');
  }
  function source(k){return k==='strain'?state.strains:k==='dispensary'?state.dispensaries:b.items;}
  function recap(row){
    const p=runBuild01Fixture('polls',{},state,actor,users,profile).polls.find(p=>p.closed&&p.id===row.poll);
    return {...row,recap:p?{question:p.question,options:p.options}:null};
  }
  const acts=[
    ...state.strain_reviews.filter(v=>!hidden({kind:'strain',id:v.strain_id})).map(v=>[v.user_id,'reviews',v.created_at,'strain:'+v.strain_id+':'+v.product_type]),
    ...state.dispensary_reviews.filter(v=>!hidden({kind:'dispensary',id:v.dispensary_id})).map(v=>[v.user_id,'reviews',v.created_at,'dispensary:'+v.dispensary_id]),
    ...b.reviews.filter(v=>!rows.some(r=>r.id===v.id&&hidden(r))).map(v=>[v.actor,'reviews',v.activity_at,'item:'+v.id]),
    ...h.submissions.filter(v=>v.created_new&&!hidden({kind:v.kind,id:v.listing})).map(v=>[v.actor,'contributions',v.decided_at]),
    ...b.polls.flatMap(p=>Object.keys(p.votes).map(v=>[v,'polls',p.voteDates?.[v]]))
  ];
  const rankings=users.map(u=>{
    const count=k=>acts.filter(a=>a[0]===u&&a[1]===k).length;
    const reviews=new Set(acts.filter(a=>a[0]===u&&a[1]==='reviews').map(a=>a[3])).size,contributions=count('contributions'),polls=count('polls');
    return {username:profile(state,u).username,reviews,contributions,polls,score:reviews+3*contributions+polls};
  });
  if(operation==='role')return role;
  if(operation==='catalog')return rows.filter(r=>!hidden(r)&&(!kind||r.kind===kind));
  if(operation==='library')return h.library.filter(r=>r.kind===kind&&(r.published||(staff&&payload.manage))).sort((a,b)=>a.position-b.position).map(recap);
  if(operation==='profile'){
    const u=users.find(u=>profile(state,u).username?.toLowerCase()===String(payload.username).toLowerCase());
    if(!u)return null;
    const p=profile(state,u);
    if(!p.show_review_identity)return null;
    const r=rankings.find(r=>r.username===p.username);
    return {username:p.username,avatar_choice:p.avatar_choice,badges:[r.reviews>=5?'Top Reviewer':null,r.contributions>=3?'Catalog Pioneer':null,r.polls>=3?'Community Voice':null,r.score>=12?'Rated420 Elite':null].filter(Boolean)};
  }
  if(!actor)throw Error('Sign in to continue');
  if(operation==='mine')return h.submissions.filter(s=>s.actor===actor);
  if(operation==='submit'){
    const name=String(payload.name??'').trim(), location=String(payload.location??'').trim(), description=String(payload.description??'').trim();
    validate(kind,name,location,description);
    if(payload.photo&&!payload.photo.startsWith(actor+'/'))throw Error('Upload your supporting image first');
    if(rows.some(r=>same(r,kind,name,location)))throw Error('A matching catalog entry already exists');
    if(h.submissions.some(r=>r.id!==id&&['Pending','Needs Revision'].includes(r.status)&&same(r,kind,name,location)))throw Error('A matching suggestion is already pending');
    const entry={kind,name,location,description,status:'Pending'};
    if(!id){
      const created={...entry,id:crypto.randomUUID(),actor,photo:payload.photo,created_at:now};
      h.submissions.push(created);
      return created.id;
    }
    const previous=h.submissions.find(r=>r.id===id&&r.actor===actor&&r.status==='Needs Revision'&&r.kind===kind);
    if(!previous)throw Error('Only your submissions needing revision can be resubmitted');
    Object.assign(previous,entry,{photo:payload.photo??previous.photo});
    return id;
  }
  if(!staff)throw Error('Rated420 HQ access required');
  if(operation==='queue')return h.submissions;
  if(operation==='manage_catalog')return rows.map(r=>({...r,archived:hidden(r)}));
  if(operation==='moderate'){
    const s=h.submissions.find(s=>s.id===id);
    if(!s)throw Error('Submission missing');
    if(['Approved','Rejected'].includes(s.status))return s.listing;
    const {status,note=''}=payload;
    if(!['Approved','Rejected','Needs Revision'].includes(status))throw Error('Choose a moderation decision');
    const {name=s.name,location=s.location,description=s.description}=payload;
    validate(s.kind,name,location,description);
    let listing=null,created_new=false;
    if(status==='Approved'){
      const existing=payload.listing?rows.find(r=>r.kind===s.kind&&String(r.id)===payload.listing):rows.find(r=>same(r,s.kind,name,location));
      if(payload.listing&&!existing)throw Error('Matching listing not found');
      if(existing)listing=existing.id;
      else {
        const list=source(s.kind);
        listing=['strain','dispensary'].includes(s.kind)?Math.max(0,...list.map(r=>Number(r.id)))+1:s.kind+'-'+s.id;
        list.push({id:listing,kind:s.kind,name,location,description,created_at:now});
        created_new=true;
      }
    }
    Object.assign(s,{name,location,description,status,note,listing,created_new,decided_at:now});
    return listing;
  }
  if(operation==='catalog_edit'){
    const row=source(kind).find(r=>String(r.id)===String(id));
    if(!row)throw Error('Listing not found');
    const {name,location='',description=''}=payload;
    validate(kind,name,location,description);
    if(rows.some(r=>String(r.id)!==String(id)&&same(r,kind,name,location)))throw Error('A matching listing exists');
    Object.assign(row,{name,location,description});
    h.archive=h.archive.filter(v=>v!==kind+':'+id);
    if(String(payload.archived)==='true')h.archive.push(kind+':'+id);
    return null;
  }
  if(operation==='library_save'){
    const {title,description='',image='',url='',release_date='',poll='',published,position=0}=payload;
    if(!['episode','merch'].includes(kind)||title.trim().length<2||title.length>120||description.length>1500||
       (url&&!/^https:\/\/www\.youtube\.com\/watch\?v=[\w-]{11}$/.test(url))||
       (kind==='merch'&&(url||release_date||poll))||
       (poll&&!b.polls.some(p=>p.id===poll&&p.closed)))throw Error('Enter a valid library entry');
    const old=h.library.find(r=>r.id===id&&r.kind===kind);
    if(id&&!old)throw Error('Library entry not found');
    const record={kind,title,description,image,url,release_date,poll,position:Number(position),published:String(published)==='true'};
    if(old)Object.assign(old,record);
    else h.library.push({...record,id:crypto.randomUUID()});
    return old?.id??h.library.at(-1).id;
  }
  if(operation==='staff_role'&&role==='administrator'){
    if(id===actor||!users.includes(id)||!['member','staff'].includes(payload.status))throw Error('Choose another demo account and a valid role');
    h.roles[id]=payload.status;
    return null;
  }
  if(operation==='analytics'){
    const days=[7,30,90].includes(Number(payload.days))?Number(payload.days):30;
    const counts=values=>values.reduce((result,key)=>{result[key]=(result[key]??0)+1;return result;},{});
    const recent=a=>Date.parse(a[2])>=Date.now()-days*86400000;
    const by=k=>acts.filter(a=>a[1]===k);
    const trend=Object.entries(counts(by('polls').filter(recent).map(a=>a[2].slice(0,10)))).sort().map(([day,votes])=>({day,votes}));
    return {days,accounts:users.length,catalog:counts(rows.filter(r=>!hidden(r)).map(r=>r.kind)),
      reviews:by('reviews').length,periodReviews:by('reviews').filter(recent).length,
      formats:counts(state.strain_reviews.filter(r=>!hidden({kind:'strain',id:r.strain_id})).map(r=>r.product_type)),
      submissions:counts(h.submissions.map(r=>r.status)),activePolls:b.polls.filter(p=>!p.closed).length,
      closedPolls:b.polls.filter(p=>p.closed).length,votes:by('polls').length,participants:new Set(by('polls').map(a=>a[0])).size,
      unknownVoteDates:by('polls').filter(a=>!a[2]).length,unknownReviewDates:by('reviews').filter(a=>!a[2]).length,trend,rankings};
  }
  throw Error('Action unavailable');
}

/* UI test double, not database security. Included only by this feature preview build. */
(function installCommunityDemo() {
  'use strict';
  const key='rated420-community-demo-v1';
  const actorKey=key+'-actor';
  const users=['11111111-1111-4111-8111-111111111111','22222222-2222-4222-8222-222222222222','aaaa0000-0000-4000-8000-000000000002','aaaa0000-0000-4000-8000-000000000003','aaaa0000-0000-4000-8000-000000000004'];
  const complete=typeof COMPLETE_ACCOUNTS!=='undefined';
  if(complete)users.splice(0,users.length,...COMPLETE_ACCOUNTS.map(account=>account.id));
  const callbacks=[];
  const clone=value=>JSON.parse(JSON.stringify(value));
  const read=()=>{
    let state;
    try{state=JSON.parse(localStorage.getItem(key));}catch{}
    if(!state)return clone(COMMUNITY_DEMO_SEED);
    if(complete&&window.Rated420CatalogueFixtures){
      const additions=window.Rated420CatalogueFixtures.licensed;
      for(const row of COMMUNITY_DEMO_SEED.dispensaries){
        if(additions.some(item=>item.reviewId===row.id)&&!state.dispensaries.some(item=>item.id===row.id))state.dispensaries.push({...row});
      }
    }
    return state;
  };
  const save=data=>localStorage.setItem(key,JSON.stringify(data));
  const photoBlobs = new Map();
  const photoUrls = new Map();
  const photoDb = new Promise((resolve, reject) => {
    const opening = indexedDB.open(key + '-photos', 1);
    opening.onupgradeneeded = () => opening.result.createObjectStore('photos');
    opening.onsuccess = () => resolve(opening.result);
    opening.onerror = () => reject(opening.error);
    opening.onblocked = () => reject(new Error('Another tab is blocking demo photo storage.'));
  });
  async function photoTransaction(mode, operation) {
    const database = await photoDb;
    return new Promise((resolve, reject) => {
      const transaction = database.transaction('photos', mode);
      operation(transaction.objectStore('photos'));
      transaction.oncomplete = resolve;
      transaction.onabort = () => reject(transaction.error);
    });
  }
  const loadedPhotos = photoTransaction('readonly', store => {
    const cursor = store.openCursor();
    cursor.onsuccess = () => {
      if (!cursor.result) return;
      photoBlobs.set(cursor.result.key, cursor.result.value);
      cursor.result.continue();
    };
  }).catch(() => {});
  function forgetPhoto(photoKey) {
    if (photoUrls.has(photoKey)) URL.revokeObjectURL(photoUrls.get(photoKey));
    photoUrls.delete(photoKey);
    photoBlobs.delete(photoKey);
  }
  function photoUrl(bucket, path) {
    const photoKey = bucket + '/' + path;
    if (photoBlobs.has(photoKey) && !photoUrls.has(photoKey)) {
      photoUrls.set(photoKey, URL.createObjectURL(photoBlobs.get(photoKey)));
    }
    return photoUrls.get(photoKey) || read().photos?.[path];
  }
  const photoFailure = failure => ({
    data:null, error:{message:failure?.name === 'QuotaExceededError'
      ? 'Demo image storage is full. Try a smaller image or reset the demo.'
      : 'Demo image storage is unavailable. Check your browser settings and try again.'}
  });
  const ownsPhoto = path => Boolean(actor && path.split('/')[0] === actor);
  let actor=localStorage.getItem(actorKey)||'';
  const accounts=()=>complete?[...COMPLETE_ACCOUNTS,...(read().localAccounts||[])]:[];
  const account=id=>accounts().find(entry=>entry.id===id);
  const user=()=>actor?{id:actor,email:account(actor)?.email||'demo-'+(users.indexOf(actor)+1)+'@example.test',created_at:'2026-01-01T00:00:00Z',user_metadata:{}}:null;
  const error=message=>({data:null,error:{message}});
  const categories={strain_reviews:['aesthetic','aroma','flavor','effects','overall'],dispensary_reviews:['aesthetic','accessibility','staff','menu','overall']};
  function aggregate(rows,idField,fields,format=null) {
    const contributions=new Map();
    for(const row of rows){
      if(format!==null&&row.product_type!==format)continue;
      const key=String(row[idField])+'/'+row.user_id;
      if(!contributions.has(key))contributions.set(key,[]);
      contributions.get(key).push(row);
    }
    const listings=new Map();
    for(const values of contributions.values()){
      const id=values[0][idField];if(!listings.has(id))listings.set(id,[]);
      listings.get(id).push(Object.fromEntries(['total',...fields].map(f=>[f,values.reduce((sum,row)=>sum+Number(row[f]),0)/values.length])));
    }
    return [...listings].map(([id,values])=>({[idField]:id,...(idField==='strain_id'?{product_type:format}:{}),review_count:values.length,
      ...Object.fromEntries(['total',...fields].map(f=>['avg_'+f,values.reduce((sum,row)=>sum+row[f],0)/values.length]))}));
  }
  const demoProfile = (state, id) => ({
    id, username: ['demo_a','demo_b','demo_admin','demo_staff','demo_member'][users.indexOf(id)] || 'demo_member', display_name: 'Demo reviewer',
    created_at: '2026-01-01T00:00:00Z', avatar_choice: id === users[0] ? 2 : 3,
    show_review_identity: true, ...(account(id)?{username:account(id).username,display_name:account(id).name}:{}), ...state.demoProfiles?.[id]
  });
  function roles(){
    return complete?Object.fromEntries(COMPLETE_ACCOUNTS.filter(entry=>entry.role).map(entry=>[entry.id,entry.role])):undefined;
  }
  const reviewFields=categories.strain_reviews;
  function visibleReviews(state){
    return state.strain_reviews.filter(row=>!state.build02?.archive?.includes('strain:'+row.strain_id));
  }
  if(complete)window.RatedComplete={
    actor:()=>actor,
    founder:()=>Boolean(account(actor)?.founder),
    business:()=>account(actor)?.organization,
    entities:COMPLETE_ENTITIES,
    formats:COMPLETE_REVIEW_FORMATS,
    products(){const state=read();return state.strains.filter(row=>!state.build02?.archive?.includes('strain:'+row.id));},
    publish(row,text,owner){
      if(!actor||actor!==owner)throw Error('Sign in as the journal owner to publish.');
      if(account(actor)?.organization)throw Error('Business personas use catalogue proposals. Community scoring requires a reviewer persona.');
      if(row.status!=='Tried'||!COMPLETE_REVIEW_FORMATS.includes(row.format)||row.scores.length!==5||
        row.scores.some(n=>!Number.isInteger(n)||n<0||n>84)||text.length>1200)throw Error('Complete a valid strain scorecard before publishing.');
      const state=read();
      const product=state.strains.find(item=>row.productId?item.id===row.productId:item.name.toLowerCase()===row.product.toLowerCase());
      if(!product||state.build02?.archive?.includes('strain:'+product.id))throw Error('Choose an active Rated420 strain before publishing.');
      const brand=row.brand.trim()||'Unbranded';
      const reviews=state.strain_reviews;
      const linked=reviews.find(item=>item.user_id===actor&&item.journal_id===row.id);
      const same=reviews.find(item=>item.user_id===actor&&item.strain_id===product.id&&item.product_type===row.format&&item.brand.toLowerCase()===brand.toLowerCase());
      if(same&&same!==linked)throw Error('A scorecard for this product, brand and format already exists. Edit it from your account.');
      const now=new Date().toISOString();
      const review={id:linked?.id||crypto.randomUUID(),user_id:actor,strain_id:product.id,brand,product_type:row.format,
        notes:text,photo_path:linked?.photo_path??null,journal_id:row.id,total:row.scores.reduce((sum,n)=>sum+n,0),
        created_at:linked?.created_at||now,updated_at:now,...Object.fromEntries(reviewFields.map((key,i)=>[key,row.scores[i]]))};
      state.strain_reviews=[...reviews.filter(item=>item!==linked),review];
      save(state);
      window.dispatchEvent(new Event('rated420:journal-published'));
    },
    publicReviews(){
      const state=read();
      return visibleReviews(state).filter(row=>row.journal_id).map(row=>({
        product:state.strains.find(item=>item.id===row.strain_id)?.name,productId:row.strain_id,
        format:row.product_type,total:row.total,text:row.notes
      }));
    }
  };
  const normalized=row=>({...row,brand_key:row.brand?.trim().toLowerCase(),name_key:row.name?.trim().toLowerCase(),location_key:row.location?.trim().toLowerCase()});
  class Query {
    constructor(table){this.table=table;this.filters=[];this.operation='read';this.max=Infinity;this.orders=[];}
    select(columns,options={}){this.columns=columns;this.options=options;return this;}
    range(from,to){this.start=from;this.max=to+1;return this;}
    is(field,value){this.filters.push(row=>normalized(row)[field]==null);return this;}
    eq(field,value){this.filters.push(row=>String(normalized(row)[field])===String(value));return this;}
    order(field,{ascending=true}={}){this.orders.push([field,ascending]);return this;}
    limit(n){this.max=n;return this;}
    maybeSingle(){this.one='maybe';return this;}
    single(){this.one='required';return this;}
    insert(value){this.operation='insert';this.value=value;return this;}
    update(value){this.operation='update';this.value=value;return this;}
    delete(){this.operation='delete';return this;}
    then(resolve,reject){return loadedPhotos.then(()=>this.run()).then(resolve,reject);}
    run(){
      const state=read();let rows=state[this.table]||[];
      if(complete&&this.operation==='read'&&this.table==='strains')rows=rows.filter(item=>!state.build02?.archive?.includes('strain:'+item.id));
      if(complete&&this.operation==='read'&&this.table==='dispensaries')rows=rows.filter(item=>!state.build02?.archive?.includes('dispensary:'+item.id));
      if(this.table==='strain_community_stats')rows=[...aggregate(state.strain_reviews,'strain_id',categories.strain_reviews),
        ...[...new Set(state.strain_reviews.map(r=>r.product_type))].flatMap(format=>aggregate(state.strain_reviews,'strain_id',categories.strain_reviews,format))];
      if(this.table==='dispensary_community_stats')rows=aggregate(state.dispensary_reviews,'dispensary_id',categories.dispensary_reviews);
      if(this.table==='member_profiles')rows=actor?[demoProfile(state,actor)]:[];
      if(this.table==='strain_community_reviews')rows=state.strain_reviews.map(review=>{
        const {username,avatar_choice,show_review_identity}=demoProfile(state,review.user_id);
        const {id,strain_id,product_type,total,created_at}=review;
        return {id,strain_id,product_type,total,created_at,
          username: show_review_identity ? username : null,
          avatar_choice: show_review_identity && username ? avatar_choice : null};
      });
      const matches=row=>this.filters.every(filter=>filter(row));
      if(this.operation!=='read'){
        if(!actor)return error('Choose a demo reviewer in the preview toolbar first.');
        if(complete&&account(actor)?.organization&&categories[this.table])return error('Business personas cannot change community scores.');
        if(this.table==='member_profiles'&&this.operation==='update'&&rows.some(matches)){
          state.demoProfiles||={};
          state.demoProfiles[actor]={...rows[0],...this.value};
          save(state);
          return {data:clone(state.demoProfiles[actor]),error:null};
        }
        if(!['strains','dispensaries','strain_reviews','dispensary_reviews'].includes(this.table))return error('This action is disabled in the community preview.');
        if(this.operation==='insert'){
          let row={...this.value};
          if(categories[this.table]){
            if(row.user_id&&row.user_id!==actor)return error('Cannot write another demo account’s review.');
            row.user_id=actor;row.total=categories[this.table].reduce((sum,f)=>sum+Number(row[f]),0);
          }
          const duplicate=other=>this.table==='strain_reviews'?other.user_id===row.user_id&&Number(other.strain_id)===Number(row.strain_id)&&other.brand.trim().toLowerCase()===row.brand.trim().toLowerCase()&&other.product_type===row.product_type:
            this.table==='dispensary_reviews'?other.user_id===row.user_id&&Number(other.dispensary_id)===Number(row.dispensary_id):other.name.trim().toLowerCase()===row.name.trim().toLowerCase()&&(this.table!=='dispensaries'||other.location.trim().toLowerCase()===row.location.trim().toLowerCase());
          if(rows.some(duplicate))return {data:null,error:{code:'23505',message:'Duplicate demo review or listing.'}};
          row.id=categories[this.table]?crypto.randomUUID():Math.max(0,...rows.map(r=>Number(r.id)))+1;
          row.created_at=new Date().toISOString();row.updated_at=row.created_at;state[this.table]=[...rows,row];rows=[row];
        }else{
          const selected=rows.filter(row=>matches(row)&&row.user_id===actor);
          if(this.operation==='delete')state[this.table]=rows.filter(row=>!selected.includes(row));
          else{
            for(const row of selected){Object.assign(row,this.value);if(categories[this.table])row.total=categories[this.table].reduce((sum,f)=>sum+Number(row[f]),0);row.updated_at=new Date().toISOString();}
            const identities=rows.map(row=>this.table==='strain_reviews'?[row.user_id,row.strain_id,row.brand.trim().toLowerCase(),row.product_type].join('/'):[row.user_id,row.dispensary_id].join('/'));
            if(new Set(identities).size!==identities.length)return {data:null,error:{code:'23505',message:'Duplicate demo review.'}};
            state[this.table]=rows;
          }
          rows=selected;
        }
        save(state);
      }else rows=rows.filter(matches);
      for(const [field,asc] of [...this.orders].reverse())rows=[...rows].sort((a,b)=>String(a[field]).localeCompare(String(b[field]))*(asc?1:-1));
      const count=this.options?.count==='exact'?rows.length:null;
      rows=rows.slice(this.start||0,this.max);
      if(this.columns&&this.columns!=='*')rows=rows.map(row=>Object.fromEntries(this.columns.split(',').map(f=>f.trim()).map(f=>[f,row[f]])));
      if(this.one){if(rows.length>1||(!rows.length&&this.one==='required'))return error('Expected one demo record.');return {data:rows[0]||null,error:null};}
      return {data:this.options?.head?null:clone(rows),count,error:null};
    }
  }
  const emit=event=>callbacks.forEach(cb=>cb(event));
  window.supabase={createClient:()=>({from:table=>new Query(table),
    rpc:async(name,{operation,payload})=>{
      if(!['rated420_build01','rated420_build02'].includes(name))return error('Unknown fixture operation.');
      try {
        const state=read();
        if(name==='rated420_build02'){
          await loadedPhotos;
          if(payload.photo && !photoBlobs.has('catalog-submissions/'+payload.photo))return error('Upload your supporting image first.');
          const data=runBuild02Fixture(operation,payload,state,actor,complete?accounts().map(entry=>entry.id):users,demoProfile,aggregate,roles());
          if(['submit','moderate','catalog_edit','library_save','staff_role'].includes(operation))save(state);
          return {data,error:null};
        }
        if(complete&&account(actor)?.organization&&operation==='review')return error('Business personas cannot change community scores.');
        const data=runBuild01Fixture(operation,payload,state,actor,users,demoProfile);
        if(['favorite','review','vote','publish','close'].includes(operation))save(state);
        return {data,error:null};
      } catch(failure) { return error(failure.message); }
    },auth:{
    getUser:async()=>({data:{user:user()},error:null}),
    onAuthStateChange:cb=>{callbacks.push(cb);return {data:{subscription:{unsubscribe(){}}}};},
    signOut:async()=>{activate('');return {error:null};},
    signInWithPassword:async({email,password})=>{
      if(!complete)return error('Use the demo reviewer selector above. Do not enter real credentials.');
      const entry=accounts().find(item=>item.email===email.toLowerCase());
      if(!entry||password!=='demo-only-420')return error('Use a synthetic email and the shared demo password shown on this page.');
      activate(entry.id);return {data:{user:user(),session:{}},error:null};
    },
    signUp:async({email,password,options})=>{
      if(!complete)return error('Real signups are disabled. Use the demo reviewer selector.');
      const name=options.data.requested_username;
      if(!/^[^@ ]+@example\.test$/i.test(email)||password!=='demo-only-420')return error('Use an @example.test address and the shared demo password.');
      if(accounts().some(entry=>entry.email===email.toLowerCase()||entry.username.toLowerCase()===name.toLowerCase()))return error('That synthetic email or username is already in use.');
      const entry={id:crypto.randomUUID(),label:'Local member · '+name,username:name,name,email:email.toLowerCase()};
      const state=read();state.localAccounts??=[];state.localAccounts.push(entry);save(state);
      addOption(entry.id,entry.label);activate(entry.id);return {data:{user:user(),session:{}},error:null};
    },
    resetPasswordForEmail:async()=>error('Email is disabled in this preview.'),updateUser:async()=>error('Credential changes are disabled in this preview.')
  },storage:{from:bucket=>({
    upload:async(path,file)=>{
      if (!ownsPhoto(path)) return error('This demo image belongs to another account.');
      try {
        await loadedPhotos;
        const photoKey=bucket+'/'+path;
        await photoTransaction('readwrite', store=>store.add(file,photoKey));
        photoBlobs.set(photoKey,file);
        return {data:{path},error:null};
      } catch(failure) { return photoFailure(failure); }
    },
    getPublicUrl:path=>({data:{publicUrl:bucket==='member-avatars' ? '' : photoUrl(bucket,path) || ''}}),
    remove:async paths=>{
      if (!paths.every(ownsPhoto)) return error('This demo image belongs to another account.');
      try {
        await loadedPhotos;
        await photoTransaction('readwrite', store=>{for (const path of paths) store.delete(bucket+'/'+path);});
        const data=read();
        for (const path of paths) {
          forgetPhoto(bucket+'/'+path);
          if (data.photos) delete data.photos[path];
        }
        if (data.photos) save(data);
        return {data:[],error:null};
      } catch(failure) { return photoFailure(failure); }
    },
    createSignedUrl:async path=>{
      if (bucket==='catalog-submissions' && !ownsPhoto(path) && !(
        (read().build02?.roles ?? roles() ?? {[users[0]]:'staff',[users[2]]:'administrator',[users[3]]:'staff'})[actor] &&
        (read().build02?.roles ?? {})[actor]!=='member'))return error('This submission photo is private.');
      if (bucket==='member-avatars' && !ownsPhoto(path)) return error('This demo image belongs to another account.');
      await loadedPhotos;
      const signedUrl=photoUrl(bucket,path);
      return signedUrl ? {data:{signedUrl},error:null} : error('Demo image is unavailable.');
    }
  })}})};
  const nativeFetch=window.fetch.bind(window);
  window.fetch=(input,init)=>{const url=new URL(typeof input==='string'?input:input.url,location.href);return url.hostname==='rated420-demo.invalid'||url.hostname.endsWith('.supabase.co')?Promise.resolve(Response.json({ready:false,success:false},{status:503})):nativeFetch(input,init);};
  const banner=document.createElement('aside');banner.setAttribute('aria-label','Synthetic data preview');banner.style.cssText='padding:14px;background:#253925;color:#eff7e8;position:relative;z-index:10;font:14px sans-serif;display:flex;gap:12px;align-items:center;flex-wrap:wrap';
  const label=document.createElement('label');label.textContent='SYNTHETIC DATA PREVIEW · Simulated roles and records. Demo reviewer: ';
  const select=document.createElement('select');select.id='demoReviewer';select.style.cssText='padding:8px;background:#111711;color:#eff7e8;max-width:100%';
  function addOption(value,text){const option=document.createElement('option');option.value=value;option.textContent=text;select.append(option);}
  const choices=complete?accounts().map(entry=>[entry.id,entry.label]):[[users[0],'Reviewer A'],[users[1],'Reviewer B'],[users[4],'Regular member'],[users[3],'Staff member'],[users[2],'Administrator']];
  for(const [value,text] of [['','Logged-out visitor'],...choices])addOption(value,text);
  function activate(id){
    actor=id;select.value=actor;
    if(actor)localStorage.setItem(actorKey,actor);else localStorage.removeItem(actorKey);
    if(complete&&select.value!==id)select.value='';
    emit(actor?'SIGNED_IN':'SIGNED_OUT');
  }
  select.value=actor;select.addEventListener('change',()=>activate(select.value));label.append(select);banner.append(label);
  const reset=document.createElement('button');reset.type='button';reset.textContent='Reset demo data';reset.style.cssText='padding:8px;background:#c7ea86;color:#111711';reset.addEventListener('click',async()=>{
    try {
      await photoTransaction('readwrite', store=>store.clear());
      localStorage.removeItem(key);
      if(complete){
        localStorage.removeItem(actorKey);
        for(const name of Object.keys(localStorage))if(/^rated420-(?:expansion-v1:|gary-preview-v1$|hq-profile-examples-v1$|complete-contact-v1$|intelligence-v1$|editorial-v1$|catalogue-v1$)/.test(name))localStorage.removeItem(name);
        history.replaceState(null,'',location.pathname);
      }
      location.reload();
    } catch {
      reset.textContent='Could not reset demo images. Try again.';
    }
  });banner.append(reset);
  const note=document.createElement('span');note.textContent='Scores and edits persist only in this browser. No real emails or accounts.';banner.append(note);
  document.getElementById('siteShell').prepend(banner);
})();
